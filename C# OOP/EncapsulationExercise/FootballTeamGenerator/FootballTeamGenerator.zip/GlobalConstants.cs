﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FootballTeamGenerator
{
    public static class GlobalConstants
    {
        public const string InvalidNameErrorMessage = "A name should not be empty.";
    }
}
